import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../../servicios/productos.service';  // Ruta relativa a la nueva ubicación
import { Producto } from '../../models/producto.model';  // Ruta relativa a la nueva ubicación

@Component({
  selector: 'app-productos',
  templateUrl: './productos.page.html',
  styleUrls: ['./productos.page.scss'],
})
export class ProductosPage implements OnInit {

  productos: Producto[] = [];

  constructor(private productosService: ProductosService) { }

  ngOnInit() {
    this.obtenerProductos();
  }

  obtenerProductos() {
    this.productosService.getProductos().subscribe(data => {
      console.log(data)
      this.productos = data;
    }, error => {
      console.error('Error al obtener productos', error);
    });
  }
}
