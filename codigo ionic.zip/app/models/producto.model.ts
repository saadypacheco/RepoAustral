export interface Producto {
    nombre: string;
    descripcion: string;
    precio: number;
    imagen_url: string;
  }
  