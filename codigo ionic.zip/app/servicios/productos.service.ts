import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Producto } from '../models/producto.model';  // Ruta correcta hacia el modelo

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) { }

  // Obtener productos: aquí se retorna un array de Productos
  getProductos(): Observable<Producto[]> {
    return this.http.get<Producto[]>(`${this.apiUrl}/productos`);
  }

  // Agregar producto: aquí se espera recibir un objeto de tipo Producto
  addProducto(producto: Producto): Observable<any> {
    return this.http.post(`${this.apiUrl}/productos`, producto);
  }
}
